William Stephan Evenn Resnais Badara Tall

Déclarations ( Varglobal et constante de tout type )
Expressions ( Entière et Booléenne)
Instructions ( si , ttq, cond)
Procédure

Les appels de procédures nous ont données pas mal d'error, on a du corrigé ce qu'on avait fait pour les déclarations des procs