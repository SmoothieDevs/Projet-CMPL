William Stephan Evenn Resnais Badara Tall

Déclarations ( Varglobal et constante de tout type )
Expressions ( Entière et Booléenne)
Instructions ( si , ttq, cond)

Cond un peu compliqué à comprendre